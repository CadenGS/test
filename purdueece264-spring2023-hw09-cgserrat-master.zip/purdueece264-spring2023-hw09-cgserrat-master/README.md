
# Recursion

## Due 03/20 at 11:59pm

Learning Goals
==============

* Understand recursion
* Use transitivity to reduce redundant computation
* Sort numbers using the merge sort algorithm

Merge Sort
==========

Merge Sort is a Divide and Conquer algorithm. You can read more about [the algorithm](https://medium.com/basecs/making-sense-of-merge-sort-part-1-49649a143478).

The function has three phases:

* If the input array has only one or no element, it is already sorted
  and do nothing. This is the terminating condition.

* If the input array has two or more elements, divide the array into two non-overlapping arrays and these two arrays include all elements in the input array. Send the two arrays to the sort function.

* After the two arrays are individually sorted, merge them into one
array. Here, *transitivity* is used. Consider the two arrays [x1, x2,
..., xn] and [y1, y2, ..., ym].  Each array is already sorted: x1 <=
x2 <= ... <= xn and y1 <= y2 <= ... <= ym.  If x1 < y1, then x1 < y2,
x1 < y3 ... It is unnecessary to compare x1 with y2, or y3, ...,
ym. Transitivity is important avoiding unnecessary comparisons.


WARNINGS
========

Be very very careful about the indexes. Read your programs very
carefully to ensure that you programs do not miss any element or have
an index beyond an array's size.  Create a lot of test cases to help
you catch different scenarios.



WHAT TO SUBMIT
==============

You **must** follow the instructions precisely. Failing to follow
these instructions will likely make you receive zero in this
assignment.  Your score **is determined by your submission**, nothing
else.  The teaching staff is strictly prohibited seeing anything on
your computer for grading.

When you are ready to submit your code for grading, you need to *tag* the version you want us to grade. A tag is a way of assigning a name to a particular version of code. We look for the tag `final_ver` to decide what to grade.

1. Tag your local code: `> git tag final_ver`
2. Push the tag to GitHub: `> git push origin final_ver`

If you later decide you want to update the version you submit, you can tag a different version:

1. Update the tag: `> git tag final_ver -f`
2. Push the tag to GitHub: `git push origin final_ver -f`

We will grade whichever version has the `final_ver` tag at the due date.

You will be graded based on `main.c` and `hw09.c` and **not on `Makefile`**.
